public class Str {

    String name;

    public Str(){

    }
    public Str(String string) {
    }
    public void setName(String name){
        this.name = name;
    }
    public static void main(String[] args) {
        String s1 = "Hello";
        String s2 = "Hello";
        Str s = new Str();
        s.setName("");
        System.out.println("Comparing the constant value with the null value");
        System.out.println(s.name.equals(s1));
        Str str = new Str("Hello");
        System.out.println("Comparing the intialized value and object created value");
        System.out.println(s1.equals(str));

    }
}
