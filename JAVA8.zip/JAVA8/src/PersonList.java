

import java.util.*;
import java.util.stream.Collectors;

public class PersonList {
    public static void main(String[] args) {
        List<Person> persons = loadPersons();
        List<Person> per = persons.stream()
                //.filter(person -> person.getAge() > 20)
                .collect(Collectors.toList());
        System.out.println(per);
        Person foundPerson = persons.stream()
                .filter(person -> person.getName() .startsWith("Ma"))
                .findFirst()
                .orElse(null)
                ;
        Person per1 = persons.stream()
                .filter(person -> person.getName() .startsWith("Ma"))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("No person found with a name starting with 'ma'"));
        ;
        System.out.println(foundPerson);

        System.out.println(per1);

        Map<String, Person> personMap=per.stream()
                .collect(Collectors.toMap(Person::getName,person->person));
        System.out.println(personMap);
          //Before Java8
        Map<String,List<Person>> designation=new HashMap<>();
        for(Person person:persons)
        {
            List<Person> personList=null;
            if(designation.containsKey(person.getDegn()))
            {
                personList=designation.get(person.getDegn());
            }
            else{
                personList=new ArrayList<>();
                designation.put(person.getDegn(),personList);
            }
            personList.add(person);
        }
        System.out.println(designation);
        //Java 8
        List<Person> p=loadPersons();
        Map<String, List<Person>> result =p.stream()
                .collect(Collectors.groupingBy(Person::getDegn));
        System.out.println(result);
    }


    private static List<Person> loadPersons(){
        List<Person> personlist=new ArrayList<>();
        personlist.add(new Person("pravalli",20,"SE"));
        personlist.add(new Person("malavika",19,"Java"));
        personlist.add(new Person("Madhu",15,"SE"));
        personlist.add(new Person("akshi",21,"SSE"));
        return personlist;

    }
}
 